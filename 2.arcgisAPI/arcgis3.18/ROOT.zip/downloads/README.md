README.md
=========
This folder contains files that are part of the downloadable zip files at https://developers.arcgis.com/en/downloads/.

index.html - install instructions for Windows
install_linux/index.html - install instructions for Linux/Unix
  